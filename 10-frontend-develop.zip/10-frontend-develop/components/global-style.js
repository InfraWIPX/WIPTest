import { injectGlobal } from 'styled-components';

injectGlobal`
  @font-face {
     font-family: 'Niramit';
     src: url('../static/font/TH Niramit AS.ttf');
  }
`